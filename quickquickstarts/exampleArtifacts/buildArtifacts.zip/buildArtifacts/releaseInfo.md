# Azure VM Image Builder Demo
## The exicting app : index.html
## Release History
0.0.1 - Designed and coded on the Tube
0.0.2 - Production release, i hope this work! :-)